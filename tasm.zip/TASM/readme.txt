TASM.EXE - ezzel keszited el a forraskodbol a targykodot, amelybol
TLINK.EXE - ezzel keszitesz .EXE kiterjesztesu fajlt
ASM.EXE - na ezt az elobbi ket lepest ugye egymas utan kell vegrehajtani, nagyjabol igy, ha a leforditando program neve pelda.asm:

tasm pelda.asm
tlink pelda.obj

De miert igy csinalni, ha lehet egyszerubben is? 

asm pelda

Ez pontosan ugyanazt csinalja... :) (meghivja eloszor a tasm-ot majd a tlink-et)

TD.EXE - TURBO DEBUGGER - a deguggolashoz
AFD.EXE - ADVANCED FULLSCREEN DEBUGGER - szintugy
SYSMAN.EXE - szlovak nyelvu, hasznos informaciokat tartalmaz